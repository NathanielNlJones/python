#main program, imports func function from function_mod1

from Function_Mod1 import Func

# Test the imported function
print(Func(which='even', limit=5))