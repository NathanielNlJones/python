#-----------------------------------------------------------------------
# Function_Mod.py  - Lab 6 function to be imported by other code
#
# Accept parameters 'even' or 'odd', and 'count' 
#
# IT 109
#-----------------------------------------------------------------------

def Func (which = 'even', limit = 5):
    """Func generates the first 'x' even or odd integers.
       parameters: keyword 'which' = 'even' or 'odd'
                   keyword 'limit' = number of integers to be generated
       output = returns list of the generated integers """
    outlist = [ ]
    if which == 'even':
        start = 2
    else:
        start = 1
    return([n for n in range (start, 2*limit + 1, 2)])

# Global Code -----------------------------------------------------------
print ('1. start of code to demonstrate Func')
print ('2. First five evens:   ', Func())
print ('3. First five odds:    ', Func(which = 'even'))
print ('4. First ten evens:    ', Func(limit = 10))
print ('5. First ten odds:     ', Func(which = 'odd', limit = 10))
print ('6. end of Func demo')
       
 
